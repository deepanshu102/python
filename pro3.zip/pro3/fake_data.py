import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE",'pro3.settings')
import django
django.setup();
from app.models import users

from faker import Faker
fakegen=Faker();
def datas(N=5):
    for i in range(N):
        t=users.objects.get_or_create(f_name=fakegen.first_name(),l_name=fakegen.last_name(),email=fakegen.email())[0]
        t.save();
if __name__=='__main__':
    print('insertion start');
    datas(10);
    print("done");
