from django.shortcuts import render
from app.models import users
# Create your views here.


def index(request):
    dic={"index":'http://127.0.0.1:8000/user'}
    return render(request,'index.html',context=dic)
def login(request):
    user_li=users.objects.order_by('email');
    user_dic={'user':user_li};
    return render(request,'user.html',context=user_dic);
    
