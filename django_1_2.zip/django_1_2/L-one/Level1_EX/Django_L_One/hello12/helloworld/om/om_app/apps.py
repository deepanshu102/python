from django.apps import AppConfig


class OmAppConfig(AppConfig):
    name = 'om_app'
