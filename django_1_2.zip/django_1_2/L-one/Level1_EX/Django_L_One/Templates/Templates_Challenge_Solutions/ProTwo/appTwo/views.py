from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.

def index(request):
    return HttpResponse("<em>My Second Project11</em>")

def help(request):
    helpdict = {'help_insert':'HELP PAGE12'}
    return render(request,'apptwo/help.html',context=helpdict)
