from django.contrib import admin
from appTwo.models import User
# Register your models here.
admin.site.register(User)
