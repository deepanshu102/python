'''
#############################################
pip install Faker we use for face data
#############################
##################
'''
import os

os.environ.setdefault("DJANGO_SETTINGS_MODULE",'pro.settings')

import django

django.setup()


import random

from first_app.models import Topic,Webpages,AccessRecord #<app name>.models import all table names'''

from faker import Faker

fakegen=Faker();
topics=['Search','Social','Marketpalce','News','Games']

def add_topic():
    t=Topic.objects.get_or_create(top_name=random.choice(topics))[0]
    t.save();
    return t;


def populate(N=5):
    '''
    Create N Entries of Data AccessRecord
    '''
    for entry in range(N):
        #Get Topic for entry
        top=add_topic();
        #Create Fake Data For Entry
        fake_url=fakegen.url()
        fake_date=fakegen.date()
        fake_name=fakegen.company();
        webpg=Webpages.objects.get_or_create(topic=top,url=fake_url,name=fake_name)[0]
        accRec=AccessRecord.objects.get_or_create(name=webpg,date=fake_date)[0]


if __name__=='__main__':
    print("populating the databases .. pls Wait");
    populate(20);# pouplate(time)
    print("Populating Complete");
