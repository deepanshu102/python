from django.db import models

# Create your models here.
class repoter(models.Model):
    first=models.CharField(max_length=30,unique=True)
    last=models.CharField(max_length=30,unique=True)

    def __str__(self):
        return self.first
        return self.last



class articles(models.Model):
    name=models.ForeignKey(repoter)
    headline=models.CharField(max_length=300,unique=True);
