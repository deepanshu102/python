
import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE',"pro1.settings");
import django
django.setup()


from faker import Faker
from Apptwo.models import repoter,articles
fakegen=Faker();
def add_repoter():
    f=fakegen.company();
    l=fakegen.company();
    t=repoter.objects.get_or_create(firt=f,last=l)[0];
    t.save();
    return t;
def adding(N=5):
    for entry in range(N):
            na=add_repoter();
            line=fakegen.text();
            l=articles.objects.get_or_create(name=na,headline=line)
if __name__=='__main__':
    print("VALUES ENTERED");
    adding(21);
    print("Completed");
