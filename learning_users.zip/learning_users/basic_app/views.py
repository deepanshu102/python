from django.shortcuts import render
from basic_app.forms import UserProfileInfoForm,UserForm

#for login purpose
from django.contrib.auth import authenticate,login,logout
from django.http import HttpResponseRedirect,HttpResponse
from django.core.urlresolvers import reverse
from django.contrib.auth.decorators import login_required


# Create your views here.
def index(request):
     return render(request,'basic_app/index.html')

def base(request):
    return render(request,'basic_app/base.html')

def login(request):
    return render(request,'basic_app/login.html')

def reg(request):
    return render(request,'basic_app/reg.html')
@login_required
def special(request):
    return HttpResponse("Your are logged in.Nice!")
#@login_required is  decorators when user is login then he can logout
@login_required
def user_logout(request):
    #logout the user
    logout(request)
    #Return to homepage
    return HttpResponseRedirect(reverse('index'))
def registration(request):
    registered=False
    if request.method=='POST':
        user_form=UserForm(data=request.POST)
        profile_form=UserProfileInfoForm(data=request.POST)

        if user_form.is_valid() and profile_form.is_valid():

            #save User from to Database
            user=user_form.save();


            #HASH the Password
            user.set_password(user.password)

            #Udate with hashed password
            user.save()

            profile=profile_form.save(commit=False)
            #set one to one relationship between
            #UserForm and UserProfileInfoForm
            profile.user=user;

            if 'profile_pic' in request.FILES:
                print('found it')

                profile.profile_pic=request.FILES['profile_pic']
            profile.save()
            registered=True;
        else:
           #one of the forms was invalid if this else gets called
           print(user_form.errors,profile_form.errors)
    else:
        #was not a HTTP post so we just render the forms as blank
        user_form=UserForm();
        profile_form=UserProfileInfoForm()
    #this is the render and context dictionary to feed
    #back to the registration.html file page
    return render(request,'basic_app/reg.html',{'user_form':user_form,
                                                        'profile_form':profile_form,
                                                        'registered':registered})


def form(request):
    # form=forms.FormName()
    #
    # return render(request,'basicapp/form_page.html',context=mydict)
    form=forms.FormName()

    if request.method=='POST':
        form=forms.FormName(request.POST)
        if form.is_valid():

            print("Form validation success.Prints in console.")
            print("Name:"+form.cleaned_data['fname'])
            print("Email:"+form.cleaned_data['email'])
            # print("Verify Email:"+form.cleaned_data['verify_email'])
            # print("Text:"+form.cleaned_data['text'])

            form.save(commit=True)
            return welcome(request)
            #return welcome(request)

            # return HttpResponseRedirect('')
        else:
            print("Error")
    mydict={'form':form}
    return render(request,'basic_app/login.html',context=mydict)

def user_login(request):
    if request.method=='POST':
        user=request.POST.get("username")
        password=request.POST.get("password")

        user=authenticate(username=user,password=password)
        if user:
            if user.is_active:
                #checking to user is already login
                login(request,user)
                return HttpResponseRedirect(reverse('index'))
            else:
                #if account is not active
                return HttpResponse("YOUR ACCOUNT IS NOT ACTIVE")
        else:
            print("Someone tried to login and failed")
            print("they used username:{} and password:{}".format(username,password))
            return HttpResponse("Invalid login deails supplied")
    else:
        #Nothing has been provided for username or Password
        return render(request,'basic_app/login.html',{})
