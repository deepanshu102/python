from django.db import models
from django.contrib.auth.models import User
# Create your models here.

class UserProfileInfo(models.Model):
    #create relationship
    user=models.OneToOneField(User)

    #add extra attribute to user
    portfolio_site=models.URLField(blank=True)
    #pip install pillow
    #pip install pillow --global-option="build_ext"--global-option="--disable-jpeg"
    profile_pic=models.ImageField(upload_to='profile_pics',blank=True)

    def __str__(self):
    #username is the built in attribute of user
         return self.user.username
