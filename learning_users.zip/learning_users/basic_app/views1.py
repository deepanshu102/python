from django.shortcuts import render
from basic_app.forms import UserProfileInfo,UserForm
# Create your views here.
def index(request):
     context_dict={'text':"hello friends",'number':100}
     return render(request,'basic_app/index.html',context=context_dict)

def base(request):
    return render(request,'basic_app/base.html')

def login(request):
    return render(request,'basic_app/login.html')
def reg(request):
    return render(request,'basic_app/reg.html')

#     return render(request,'basic_app/reg.html')

def form(request):
    # form=forms.FormName()
    #
    # return render(request,'basicapp/form_page.html',context=mydict)
    form=forms.FormName()

    if request.method=='POST':
        form=forms.FormName(request.POST)
        if form.is_valid():

            print("Form validation success.Prints in console.")
            print("Name:"+form.cleaned_data['fname'])
            print("Email:"+form.cleaned_data['email'])
            # print("Verify Email:"+form.cleaned_data['verify_email'])
            # print("Text:"+form.cleaned_data['text'])

            form.save(commit=True)
            return welcome(request)
            #return welcome(request)

            # return HttpResponseRedirect('')
        else:
            print("Error")
    mydict={'form':form}
    return render(request,'basic_app/reg.html',context=mydict)
def
