a=dict(jatin=5,ben=14,kat=3,anu=4)

#lambda arguments: expression  (t[1] for values)
b=sorted(a.items(),key=lambda t:t[1])
print(b)



#lambda arguments: expression  (t[0] for keys)
b=sorted(a.items(),key=lambda t:t[0])
print(b)
