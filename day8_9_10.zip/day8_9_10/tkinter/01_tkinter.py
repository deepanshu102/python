from tkinter import *

root = Tk()  # creates a blank window
theLabel = Label(root, text="This is too easy")
theLabel.pack()  # basically places this widget inside the window
root.mainloop()  # keeps the window open, the close button breaks the loop
